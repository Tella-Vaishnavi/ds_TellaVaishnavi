
# 📌 README — Data Science Assignment (Tella Vaishnavi)

## 📁 Project Structure
ds_TellaVaishnavi/
├── notebook_1.ipynb
├── csv_files/
├── outputs/
├── ds_report.pdf
└── README.md

## 📄 Project Overview
This project analyzes trader behavior using market sentiment (Fear & Greed Index). I explored how sentiment affects trader decisions and built a simple LightGBM model to predict profitable trades.

## 🔍 Key Steps
1. Data Loading & Cleaning
---------------------------------
--Standardized all column names
--Fixed missing values
--Cleaned data types (numeric, datetime)
--Extracted useful time-based features

2. Merging Sentiment Data
--------------------------------
---Merged Fear–Greed dataset by date
--Created numeric sentiment factors
--Calculated daily sentiment exposure

3. Custom Metric – SBDS
--------------------------------
--I created a unique metric:
--Sentiment Behavior Divergence Score (SBDS)
--This measures how much a trader's daily PnL deviates from overall market mood.
Helps detect
--Sentiment-aligned traders
--Contrarian traders
--Behavior patterns during extreme fear/greed

4. Feature Engineering
----------------------------
--Log-scaled position sizes
--Side mapping (Buy/Sell → 1/0)
--Abs PnL for magnitude analysis
--Trade-level merged sentiment features

5. Machine Learning Model
-------------------------------
--I built a simple baseline:
--LightGBM classifier
--Predicts whether a trade is profitable (pnl_sign)
--Evaluated using AUC, accuracy, classification report

6. Outputs Saved
-----------------------
--Processed CSVs
--Sample model datasets
--Sentiment distribution plot
--Probability histogram
--Summary statistics

📊 Files Generated
----------------------
Inside csv_files/:

trades_processed.csv

account_daily_stats.csv

model_dataset_sample.csv

summary_metrics.csv

Inside outputs/:

sentiment_counts.png

pred_prob_hist.png

🏁 Final Notes
----------------------

$$This assignment demonstrates:

End-to-end data handling

Feature engineering

Financial data insights

ML modeling workflow

Organized project structure

It reflects my ability to work independently, understand business context, and produce clean & reproducible work.


## 🏁 Notes
This project demonstrates end-to-end data science workflow with a clean folder structure.
